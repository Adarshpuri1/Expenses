# Spreetail Shared Expenses App

A production-grade shared expense tracking application for flatmate groups. Track expenses, split bills, and settle debts with ease.

## Features

- **Group Management**: Create and manage expense sharing groups
- **Multiple Split Types**: Equal, exact, percentage, or weighted shares
- **CSV Import**: Bulk import expenses with anomaly detection
- **Currency Conversion**: Automatic conversion with cached exchange rates
- **Balance Tracking**: Real-time balance calculations
- **Settlement Suggestions**: Optimized debt simplification
- **Member Timeline**: Track membership history

## Tech Stack

### Backend
- Node.js + Express.js
- PostgreSQL + Sequelize ORM
- JWT Authentication
- bcrypt password hashing

### Frontend
- React 18 + Vite
- TailwindCSS
- Framer Motion
- Zustand state management
- Recharts for visualizations

## Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL 15+
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone <repository-url>
cd spreetail-expenses
```

2. Install dependencies
```bash
npm run install:all
```

3. Set up environment variables
```bash
cp .env.example .env
# Edit .env with your configuration
```

4. Create PostgreSQL database
```bash
createdb spreetail_expenses
# Or use psql: CREATE DATABASE spreetail_expenses;
```

5. Start development servers
```bash
npm run dev
```

The app will be available at:
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000

## Project Structure

```
spreetail-expenses/
├── server/
│   ├── config/          # Database and app configuration
│   ├── controllers/     # Request handlers
│   ├── middleware/      # Auth, rate limiting, etc.
│   ├── models/          # Sequelize models
│   ├── routes/          # API routes
│   ├── services/        # Business logic
│   ├── utils/           # Utilities
│   ├── validations/     # Input validation
│   ├── tests/           # Test files
│   └── server.js        # Entry point
│
├── client/
│   ├── src/
│   │   ├── api/         # API client
│   │   ├── components/   # React components
│   │   ├── hooks/       # Custom hooks
│   │   ├── layouts/     # Page layouts
│   │   ├── pages/       # Page components
│   │   ├── routes/      # React Router setup
│   │   ├── store/       # Zustand stores
│   │   ├── styles/      # CSS styles
│   │   └── utils/       # Utility functions
│   └── ...
│
├── README.md
├── SCOPE.md
├── DECISIONS.md
├── AI_USAGE.md
├── docker-compose.yml
└── package.json
```

## API Overview

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `POST /api/auth/refresh` - Refresh tokens
- `POST /api/auth/logout` - Logout
- `GET /api/auth/me` - Get current user

### Groups
- `POST /api/groups` - Create group
- `GET /api/groups` - List groups
- `GET /api/groups/:id` - Get group details
- `PUT /api/groups/:id` - Update group
- `DELETE /api/groups/:id` - Delete group

### Expenses
- `POST /api/groups/:id/expenses` - Create expense
- `GET /api/groups/:id/expenses` - List expenses
- `PUT /api/groups/:id/expenses/:expenseId` - Update expense
- `DELETE /api/groups/:id/expenses/:expenseId` - Delete expense

### Balances
- `GET /api/groups/:id/balances` - Get balances
- `GET /api/groups/:id/settlement-suggestions` - Get settlement suggestions

### Import
- `POST /api/groups/:id/import` - Upload CSV
- `POST /api/groups/:id/import/:sessionId/confirm` - Confirm import

## Environment Variables

| Variable | Description |
|----------|-------------|
| `DB_NAME` | PostgreSQL database name |
| `DB_USER` | Database user |
| `DB_PASSWORD` | Database password |
| `DB_HOST` | Database host |
| `DB_PORT` | Database port |
| `PORT` | Server port |
| `NODE_ENV` | Environment (development/production) |
| `JWT_ACCESS_SECRET` | JWT access token secret |
| `JWT_REFRESH_SECRET` | JWT refresh token secret |
| `CLIENT_URL` | Frontend URL for CORS |

## Docker Deployment

```bash
# Build and run with Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f
```

## Testing

```bash
# Run backend tests
npm run test

# Run specific test file
cd server && npm test -- tests/splitEngine.test.js
```

## License

MIT
